

<?php $__env->startSection('title'); ?>
    <?php echo e(__('main.resources')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h4 class="m-0 text-dark"><?php echo e(__('main.resources')); ?></h4>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('main.resources')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('admin.resource.create')); ?>"
                            class="btn btn-success btn-sm"><?php echo e(__('main.Add New')); ?></a>
                        <a href="<?php echo e(route('admin.resource.trash')); ?>" class="btn btn-warning btn-sm float-right"><i
                                class="fas fa-trash-alt"></i><?php echo e(__('main.Recycle')); ?></a>
                    </div>
                    <div class="card-body">
                        <table id="table1" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('main.id')); ?></th>
                                    <th><?php echo e(__('main.Title')); ?></th>
                                    <th><?php echo e(__('main.Category')); ?></th>
                                    <th><?php echo e(__('main.Creation Date')); ?></th>
                                    <th><?php echo e(__('main.Statu')); ?></th>
                                    <th><?php echo e(__('main.Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($article->title); ?></td>
                                        <td><?php echo e($article->getCategory->title); ?></td>
                                        <td><?php echo e($article->created_at->diffForHumans()); ?></td>
                                        <td><input class="switch" type="checkbox" name="my-checkbox"
                                                data-id="<?php echo e($article->id); ?>" <?php if($article->status == 1): ?> checked <?php endif; ?>
                                                data-toggle="toggle" data-size="mini"
                                                data-on="<?php echo e(__('main.Published')); ?>" data-off="<?php echo e(__('main.Draft')); ?>"
                                                data-onstyle="success" data-offstyle="danger"></td>
                                        <td>
                                            
                                            <a href="<?php echo e(route('admin.resource.edit', $article->id)); ?>"
                                                title="<?php echo e(__('main.Edit')); ?>" class="btn btn-primary btn-xs"><i
                                                    class="fas fa-pencil-alt"></i></a>
                                            <a href="<?php echo e(route('admin.resource.delete', $article->id)); ?>"
                                                onclick="confirmDelete(event,<?php echo e($article->id); ?>)" title="<?php echo e(__('main.Delete')); ?>"
                                                class="btn btn-danger btn-xs"><i class="far fa-times-circle"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </div><!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('.switch').change(function() {
            id = $(this).attr('data-id');
            status = $(this).prop('checked');
            $.get("<?php echo e(route('admin.resource.switch')); ?>", {
                id: id,
                status: status
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/resources/index.blade.php ENDPATH**/ ?>