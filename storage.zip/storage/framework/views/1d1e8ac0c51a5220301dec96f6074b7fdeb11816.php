

<?php $__env->startSection('title'); ?>
<?php echo e(__('main.Options')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4 class="m-0 text-dark"><?php echo e(__('main.Options')); ?></h4>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a></li>
              <li class="breadcrumb-item active"><?php echo e(__('main.Options')); ?></li>
            </ol>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <form action="<?php echo e(route('admin.option.update')); ?>" method="post" id="form">
                <?php echo csrf_field(); ?>
                <input type="hidden" class="form-control form-control-sm col-md-9" value="<?php echo e(old('logo') ?? $option['logo'] ?? ''); ?>" id="logo" name="logo">
                <input type="hidden" class="form-control form-control-sm col-md-9" value="<?php echo e(old('favicon') ?? $option['favicon'] ?? ''); ?>" id="fav" name="favicon">
                <div class="row">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-group row">
                                    <label for="title" class="col-md-3"><?php echo e(__('main.Site name')); ?></label>
                                    <input type="text" class="form-control form-control-sm col-md-9" value="<?php echo e(old('favicon') ?? $option['OP_title'] ?? ''); ?>" id="title" name="title">
                                </div>
                                <div class="form-group row">
                                    <label for="headcss" class="col-md-3"><?php echo e(__('main.Header CSS')); ?></label>
                                    <textarea type="text" class="form-control form-control-sm col-md-9" id="headcss" name="headcss" rows="10"><?php echo e(old('headcss') ?? $option['OP_headcss'] ?? ''); ?></textarea>
                                </div>
                                <div class="form-group row">
                                    <label for="headjs" class="col-md-3"><?php echo e(__('main.Header JS')); ?></label>
                                    <textarea type="text" class="form-control form-control-sm col-md-9" id="headjs" name="headjs" rows="10"><?php echo e(old('headjs') ?? $option['OP_headjs'] ?? ''); ?></textarea>
                                </div>
                                <div class="form-group row">
                                    <label for="footerjs" class="col-md-3"><?php echo e(__('main.Footer JS')); ?></label>
                                    <textarea type="text" class="form-control form-control-sm col-md-9" id="footerjs" name="footerjs" rows="10"><?php echo e(old('footerjs') ?? $option['OP_footerjs'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header">
                                <label for="media_img"><?php echo e(__('main.Logo')); ?></label>
                            </div>
                            <?php
                            use App\Models\Media;
                            $logo = Media::where('id',$option['OP_logo'])->first();
                            $favicon = Media::where('id',$option['OP_favicon'])->first();
                            ?>
                            <div class="card-body text-center">
                                <img src="<?php echo e(old('logo') ?? $logo->getUrl('thumb') ?? ''); ?>" alt="" id="logo_img" style="max-width: 100%">
                            </div>
                            <div class="card-footer">
                                <a href="javascript:void(0);" class="btn btn-xs btn-primary float-left" id="logochoose"><?php echo e(__('main.Choose Image')); ?></a>
                                <a href="javascript:void(0);" class="btn btn-xs btn-warning float-right" id="logoremove"><?php echo e(__('main.Remove Image')); ?></a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <label for="media_img"><?php echo e(__('main.Favicon')); ?></label>
                            </div>
                            <div class="card-body text-center">
                                <img src="<?php echo e(old('favicon') ?? $favicon->getUrl('thumb') ?? ''); ?>" alt="" id="fav_img" style="max-width: 100%">
                            </div>
                            <div class="card-footer">
                                <a href="javascript:void(0);" class="btn btn-xs btn-primary float-left" id="favchoose"><?php echo e(__('main.Choose Image')); ?></a>
                                <a href="javascript:void(0);" class="btn btn-xs btn-warning float-right" id="favremove"><?php echo e(__('main.Remove Image')); ?></a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-body">
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" <?php if(old('no_index') ?? $option['no_index'] ?? ''==1): ?> checked <?php endif; ?> id="no_index" name="no_index">
                                    <label for="no_index" class="custom-control-label"><?php echo e(__('main.Site No Index')); ?></label>
                                </div>
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input" type="checkbox" <?php if(old('no_follow') ?? $option['no_follow'] ?? ''==1): ?> checked <?php endif; ?> id="no_follow" name="no_follow">
                                    <label for="no_follow" class="custom-control-label"><?php echo e(__('main.Site No Follow')); ?></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" id="save-card" style="z-index: 20">
                    <div class="card-body">
                        <a href="javascript:void(0);" class="btn btn-success btn-sm float-right" id="submit"><?php echo e(__('main.Save')); ?></a>
                    </div>
                </div>
            </form>
        </div><!-- /.container-fluid -->
    </div><!-- /.content -->
</div>
<?php echo $__env->make('admin.layouts.media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

const cm1 = CodeMirror.fromTextArea(document.getElementById('headcss'), {
  lineNumbers: true,
  mode: "javascript",
  theme: "base16-dark"
});
const cm2 = CodeMirror.fromTextArea(document.getElementById('headjs'), {
  lineNumbers: true,
  mode: "javascript",
  theme: "base16-dark"
});
const cm3 = CodeMirror.fromTextArea(document.getElementById('footerjs'), {
  lineNumbers: true,
  mode: "javascript",
  theme: "base16-dark",
});

$('#logoremove').click(function(){
    $('#logo_img').attr('src','');
    $('#logo').val(1);
});
$('#favremove').click(function(){
    $('#fav_img').attr('src','');
    $('#fav').val(1);
});
$("#logochoose").click(function(){
    $("#value").val('logo');
    $(".overlay-back").css("display","block");
    $(".choose-panel").css("display","block");
    $("body").css("overflow","hidden");
});
$("#favchoose").click(function(){
    $("#value").val('fav');
    $(".overlay-back").css("display","block");
    $(".choose-panel").css("display","block");
    $("body").css("overflow","hidden");
});
$("#close").click(function(){
    $(".overlay-back").css("display","none");
    $(".choose-panel").css("display","none");
    $("body").css("overflow","unset");
});
$("#add").click(function(){
    var media_img = $("#onizleme").attr("src");
    var media_id = $("#media").val();
    var value = $("#value").val();
    $("#"+value+"_img").attr("src",media_img);
    $("#"+value).attr("value",media_id);

    $(".overlay-back").css("display","none");
    $(".choose-panel").css("display","none");
    $("body").css("overflow","unset");
});
$("#remove").click(function(){
    var media_img = "";
    var media_id = 1;
    $("#media_img").attr("src",media_img);
    $("#media_id").attr("value",media_id);
});
$('.choose-panel .thumbnail img').click(function(){
    var alt = $(this).attr("alt");
    var id = $(this).attr("id");
    var url = $(this).attr("data-url");
    var title = $(this).attr('data-title');
    $("#onizleme").attr("src",url);
    $("#media").val(id);
    $("#media_url").val(url);
    $("#media_title").val(title);
    $("#media_alt").val(alt);
    $("#form_img").attr("action",id);
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/option/index.blade.php ENDPATH**/ ?>