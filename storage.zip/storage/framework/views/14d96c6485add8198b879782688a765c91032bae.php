

<?php $__env->startSection('title'); ?>
<?php echo e(__('main.Gallery')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $data = $selected ?? ''?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
           
          <div class="col-sm-6">
            <h4 class="m-0 text-dark"><?php echo e(__('main.Gallery')); ?></h4>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?php echo e(__('main.Home')); ?></a></li>
              <li class="breadcrumb-item active"><?php echo e(__('main.Gallery')); ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="card">
              <div class="card-header">
                <div class="col-sm-4 form-group">
                  <form method="post" action="<?php echo e(route('admin.dropdown.change')); ?>">
                    <?php echo csrf_field(); ?>
                      <label for="">filter :  </label>
                    <div class="form-group">
                      <select class="form-control form-control-sm" id="category" name="data" onchange="this.form.submit()">
                          <option value="0"></option>
                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($category->id); ?>" <?php if($category->id == $data): ?> selected <?php endif; ?>>
                                  <?php echo e($category->title); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                  </div>
                </form>
                </div>
              </div>
                <div class="card-body">
                    <div class="infinite-scroll">
                        <div class="scroll-content">
                        <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $id = $media->id;
                            $media = $media->path;
                        ?>
                            <?php if($id): ?>
                            <div class="thumbnail">
                                <a href="<?php echo e(route('admin.gallery.show',$id)); ?>">
                                    <img id="<?php echo e($id); ?>" src="<?php echo e(asset($media)); ?>">
                                </a>
                            </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
              <a href="<?php echo e(route('admin.gallery.index')); ?>" class="btn btn-danger">Cancel</a>
              <a href="<?php echo e(route('admin.gallery.create')); ?>" class="btn btn-success">Add Gallery Images</a>
            </div>
        </div><!-- /.container-fluid -->
    </div><!-- /.content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/gallery/index.blade.php ENDPATH**/ ?>