

<?php $__env->startSection('title'); ?>
    <?php echo e(__('main.Contact Request')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h4 class="m-0 text-dark"><?php echo e(__('main.Contact Request')); ?></h4>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('main.Contact Request')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(route('admin.contact.trash')); ?>" class="btn btn-warning btn-sm float-right"><i
                            class="fas fa-trash-alt"></i><?php echo e(__('main.Recycle')); ?></a>
                    </div>
                    <div class="card-body">
                        <table id="table1" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('main.id')); ?></th>
                                    <th><?php echo e(__('main.Name')); ?></th>
                                    <th><?php echo e(__('main.Email')); ?></th>
                                    <th><?php echo e(__('main.Mobile')); ?></th>
                                    <th><?php echo e(__('main.Message')); ?></th>
                                    <th><?php echo e(__('main.Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key +1); ?></td>
                                        <td><?php echo e($contact->name); ?></td>
                                        <td><?php echo e($contact->email); ?></td>
                                        <td><?php echo e($contact->mobile); ?></td>
                                        <td><?php echo e($contact->message); ?></td>
                                        
                                        <td> &nbsp;
                                            <a href="<?php echo e(route('admin.contact.sendmail', $contact->id)); ?>"
                                            title="<?php echo e(__('main.Show')); ?>" class="btn btn-success btn-xs">
                                            <i class="far fa-envelope"></i></a>
                                            <a href="<?php echo e(route('admin.contact.delete', $contact->id)); ?>"
                                                onclick="confirmDelete(event,<?php echo e($contact->id); ?>)" title="<?php echo e(__('main.Delete')); ?>"
                                                class="btn btn-danger btn-xs"><i class="far fa-times-circle"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </div><!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
       
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>