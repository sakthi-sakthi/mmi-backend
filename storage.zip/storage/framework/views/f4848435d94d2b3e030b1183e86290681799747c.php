

<?php $__env->startSection('title'); ?>
    <?php echo e(__('main.Categories')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h4 class="m-0 text-dark"><?php echo e(__('main.Categories')); ?></h4>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('main.Categories')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        <a href="<?php echo e(url('admin/category/'.request()->segment(3).'/create')); ?>"
                            class="btn btn-success btn-sm"><?php echo e(__('main.Add New')); ?></a>
                    </div>
                    <div class="card-body" style="margin: 20px;">
                        <table id="table1" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('main.Id')); ?> </th>
                                    <th><?php echo e(__('main.Name')); ?></th>
                                    <th><?php echo e(__('main.Image')); ?></th>
                                    
                                    
                                    
                                    <th><?php echo e(__('main.Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($category->id); ?></td>
                                        <td><?php echo e($category->title); ?></td>
                                        <td><img src="<?php echo e($category->getMedia->id == 1 ? '' : $category->getMedia->getUrl('thumb')); ?>"
                                                alt="" style="height: 26px"></td>
                                       
                                       
                                        
                                        
                                        
                                        <td>
                                            
                                            <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>"
                                                title="<?php echo e(__('main.Edit')); ?>" class="btn btn-primary btn-xs"><i
                                                    class="fas fa-pencil-alt"></i></a>
                                            
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </div><!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/category/index.blade.php ENDPATH**/ ?>