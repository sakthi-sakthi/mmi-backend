

<?php $__env->startSection('title'); ?>
<?php echo e(__('main.Edit User')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4 class="m-0 text-dark"><?php echo e(__('main.Edit User')); ?></h4>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.user.index')); ?>"><?php echo e(__('main.Users')); ?></a></li>
              <li class="breadcrumb-item active"><?php echo e($user->username); ?></li>
            </ol>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <form action="<?php echo e(route('admin.user.update',$user->id)); ?>" method="post" id="form">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="title"><?php echo e(__('main.E-mail')); ?></label>
                                    <input type="text" class="form-control form-control-sm" id="title" name="email" value="<?php echo e($user->email); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="name"><?php echo e(__('main.Name')); ?></label>
                                    <input type="text" class="form-control form-control-sm" id="name" name="name" value="<?php echo e($user->name); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="surname"><?php echo e(__('main.Surname')); ?></label>
                                    <input type="text" class="form-control form-control-sm" id="surname" name="surname" value="<?php echo e($user->surname); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="role"><?php echo e(__('main.Role')); ?></label>
                                    <select name="role" id="role" class="form-control form-control-sm">
                                        <option value="user" <?php if($user->role=="user"): ?> selected <?php endif; ?>><?php echo e(__('main.User')); ?></option>
                                        <option value="admin" <?php if($user->role=="admin"): ?> selected <?php endif; ?>><?php echo e(__('main.Admin')); ?></option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="password" class="float-left mr-3"><?php echo e(__('main.Password')); ?></label>
                                    <a href="javascript:void(0)" class="btn btn-primary btn-xs float-left" id="pass"><?php echo e(__('main.Create Password')); ?></a>
                                    <a href="javascript:void(0)" class="btn btn-primary btn-xs float-left" style="display: none" id="canc"><?php echo e(__('main.Cancel')); ?></a>
                                    <input type="text" class="form-control form-control-sm" style="display: none" id="password" name="password" value="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                    </div>
                    <div class="card" id="save-card">
                        <div class="card-body">
                            <a href="javascript:void(0);" class="btn btn-success btn-sm float-right" id="submit"><?php echo e(__('main.Update')); ?></a>
                            <a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-danger btn-sm float-right mr-2">Cancel</a>
                        </div>
                    </div>
                </div>
            </form>
        </div><!-- /.container-fluid -->
    </div><!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $("#pass").click(function(){
        $("#password").css('display',"block");
        $("#canc").css('display',"block");
        $("#pass").css('display',"none");
    })
    $("#canc").click(function(){
        $("#password").css('display',"none");
        $("#password").val(null);
        $("#canc").css('display',"none");
        $("#pass").css('display',"block");
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>