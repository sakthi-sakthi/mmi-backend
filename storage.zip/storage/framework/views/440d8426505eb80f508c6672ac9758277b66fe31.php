

<?php $__env->startSection('title'); ?>
    <?php echo e($media->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4 class="m-0 text-dark"><?php echo e($media->name); ?></h4>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.media.index')); ?>"><?php echo e(__('main.Media')); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e($media->name); ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <a href="<?php echo e(route('admin.media.index')); ?>" class="btn btn-danger float-right btn-sm"><i class="fas fa-times"></i></a>
                        </div>
                        <div class="card-body">
                            <?php
                                $id = $media->id;
                                $media = $media->getMedia();
                            ?>
                            <div class="row">
                                <div class="col-md-8 text-center">
                                    <img class="border" style="max-width: 100%; background-color: whitesmoke" src="<?php echo e($media[0]->getUrl()); ?>" alt="">
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(__('main.Name')); ?></label>
                                        <input type="text" class="form-control form-control-sm" disabled="" value="<?php echo e($media[0]->name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo e(__('main.Alt Tag')); ?></label>
                                        <input type="text" class="form-control form-control-sm" disabled="" value="<?php echo e($media[0]->alt); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label><?php echo e(__('main.Url')); ?></label>
                                        <input type="text" class="form-control form-control-sm" disabled="" value="<?php echo e($media[0]->getUrl()); ?>">
                                    </div>
                                    <form action="<?php echo e(route('admin.media.destroy',$id)); ?>" method="post" class="d-inline">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" title="Sil" class="btn btn-danger btn-xs float-right ml-2"><?php echo e(__('main.Delete')); ?></button>
                                    </form>
                                    <a href="<?php echo e(route('admin.media.edit',$id)); ?>" class="btn btn-primary btn-xs float-right ml-2"><?php echo e(__('main.Edit')); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </div><!-- /.content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/media/show.blade.php ENDPATH**/ ?>