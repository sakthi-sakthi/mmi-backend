

<?php $__env->startSection('title'); ?>
<?php echo e(__('main.Upload')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4 class="m-0 text-dark"><?php echo e(__('main.Upload')); ?></h4>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.gallery.index')); ?>"><?php echo e(__('main.Gallery')); ?></a></li>
              <li class="breadcrumb-item active"><?php echo e(__('main.Upload')); ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="card">
                <form action="<?php echo e(route('admin.gallery.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                      <div class="form-group">
                        <label for="title"><?php echo e(__('main.Title')); ?></label>
                          <input type="text"
                              class="form-control form-control-sm <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              id="title" name="title" value="<?php echo e(old('title')); ?>">
                          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="ml-auto text-danger">Title is required</small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                      <div class="form-group">
                        <label for="title"><?php echo e(__('main.Category')); ?></label>
                          <select class="form-control form-control-sm" id="category" name="category_id">
                              <option value="0"></option>
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($category->id); ?>" <?php if(old('category_id') == $category->id): ?> selected <?php endif; ?>>
                                      <?php echo e($category->title); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="ml-auto text-danger">Category is required</small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                  
                    
                      <div id="error-container"></div>
                      <div class="form-group">
                        <label for="title" >Upload Images</label>
                      <div class="needsclick dropzone" id="document-dropzone">
                      </div>
                    </div>  
                  </div>
                    <div class="card-footer">
                      <a href="<?php echo e(route('admin.gallery.index')); ?>" class="btn btn-danger">Cancel</a>
                        <button class="btn btn-success text-center px-5" type="submit" id="submit"><?php echo e(__('main.Upload')); ?></button>
                        <label class="ml-5" style="color: red"><b>Maximum file size: 5MB</b></label>
                    </div>
                </form>
            </div>
        </div><!-- /.container-fluid -->
    </div><!-- /.content -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  var uploadedDocumentMap = {};
  var secureUrl =  "<?php echo e(secure_url(route('admin.gallery.storeMedia'))); ?>";

Dropzone.options.documentDropzone = {
  url: secureUrl, 
  maxFilesize: 50, 
  addRemoveLinks: true,
  headers: {
    'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
  },
  success: function (file, response) {
    var error = response.error;
    var filesize = response.filesize;
    console.log(error,filesize);
    if (error) {
    $("#error-container").html('<div id="error-message" style="color: red;font-weight:700;">' + error + '</div>');
    $("#error-message").show();
    file.previewElement.remove();
    }else if (filesize >= 5) {
      $("#error-container").html('<div id="error-message" style="color: red;font-weight:700;"> Please reduce your file size before you upload it...! </div>');
     $("#error-message").show();
     file.previewElement.remove();
    } else {
      $('form').append('<input type="hidden" name="document[]" value="' + response.name + '">');
    uploadedDocumentMap[file.name] = response.name;
    }
    setTimeout(function() {
        $("#error-message").hide();
      }, 10000);
   
  },
  removedfile: function (file) {
    file.previewElement.remove();
    var name = '';
    if (typeof file.file_name !== 'undefined') {
      name = file.file_name;
    } else {
      name = '';
    }
    $('form').find('input[name="document[]"][value="' + name + '"]').remove();
  },
};

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/gallery/create.blade.php ENDPATH**/ ?>