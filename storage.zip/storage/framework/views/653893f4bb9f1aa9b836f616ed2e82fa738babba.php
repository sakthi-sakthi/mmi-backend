
<div class="overlay-back" style="display: none"></div>
<div class="choose-panel" style="display: none">
    <div class="row m-0">
        <div class="col-sm-9 p-0">
            <div class="card-header">
                <a href="javascript:void(0)" class="btn btn-danger btn-xs float-right" style="opacity: 0"><i class="far fa-times-circle"></i></a>
            </div>
            <div class="infinite-scroll" style="overflow:auto; height:80vh">
                <div class="scroll-content allmedia" style="display: block">
                <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $id = $media->id;
                    $media = $media->getMedia()->first();
                ?>
                <?php if($id!=1): ?>
                    <div class="thumbnail">
                        <a href="javascript:void(0);">
                            <img id="<?php echo e($id); ?>" src="<?php echo e($media->getUrl('thumb')); ?>" data-url="<?php echo e($media->getUrl()); ?>" alt="<?php echo e($media->alt); ?>" data-title="<?php echo e($media->name); ?>">
                        </a>
                    </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($medias->links()); ?>

                </div>
                <div class="add-medias" style="display: none">
                    <form id="media-form" action="<?php echo e(route('admin.media.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="media_title" value="media_title" hidden>
                        <div class="card-body"> 
                          <div id="error-container"></div> <br>
                            <div class="needsclick dropzone" id="document-dropzone">
                            </div>
                            <div class="mt-4">
                            <a href="<?php echo e(route('admin.media.index')); ?>" class="btn btn-danger">Cancel</a>
                            <button class="btn btn-success text-center px-5" type="submit" id="submitmedia"><?php echo e(__('main.Upload')); ?></button>
                            <label class="ml-5" style="color: red"><b>Maximum file size: 2MB</b></label>
                        </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-sm-3 p-0" style="background-color: whitesmoke;">
            <div class="card-header">
                <a href="javascript:void(0)" id="add_media" class="btn btn-danger btn-xs float-left"><?php echo e(__('main.Mediaadd')); ?></a>

                <a href="javascript:void(0)" class="btn btn-success btn-xs float-left ml-2" id="allmedia"><?php echo e(__('main.All Media')); ?></a>

                <a id="close" href="javascript:void(0)" class="btn btn-danger btn-xs float-right"><i class="far fa-times-circle"></i></a>
            </div>
            <div class="card-body">
                <div style="overflow: auto">
                <img src="" alt="" id="onizleme">
                <form action="" method="post" id="form_img">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="value">
                    <input type="hidden" value="" id="media" name="media">
                    <input type="hidden" value="form_img" name="form_img">
                    <div class="form-group">
                        <label for="media_title"><?php echo e(__('main.Name')); ?></label>
                        <input type="text" class="form-control form-control-sm" value="" id="media_title" name="media_title">
                    </div>
                    <div class="form-group">
                        <label for="media_alt"><?php echo e(__('main.Alt Tag')); ?></label>
                        <input type="text" class="form-control form-control-sm" value="" id="media_alt" name="media_alt">
                    </div>
                    <div class="form-group">
                        <label for="media_url"><?php echo e(__('main.Url')); ?></label>
                        <input type="text" class="form-control form-control-sm" value="" id="media_url" name="media_url" disabled>
                    </div>
                </form>
                <a href="javascript:void(0);" class="btn btn-primary btn-xs" style="bottom: 0;" id="submit_img"><?php echo e(__('main.Update')); ?></a>
                <a href="javascript:void(0);" class="btn btn-success btn-xs float-right" style="bottom: 0;" id="add"><?php echo e(__('main.Choose Image')); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/layouts/media.blade.php ENDPATH**/ ?>