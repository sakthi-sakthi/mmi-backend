

<?php $__env->startSection('title'); ?>
    <?php echo e(__('main.mainmenu')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h4 class="m-0 text-dark"><?php echo e(__('main.mainmenu')); ?></h4>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('main.Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('main.mainmenu')); ?></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                    <form action="<?php echo e(route('admin.mainmenu.store')); ?>" method="post" id="form">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <label for="title" id="label">Add Mainmenu</label>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="title"><?php echo e(__('main.Title')); ?></label>
                                                <input type="text" hidden name="type" value="store" id="typedata">
                                                <input type="text" hidden name="id" value="" id="id" hidden>
                                                <input type="text"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="title" name="title" value="<?php echo e(old('title')); ?>">
                                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="ml-auto text-danger"><?php echo e(__('main.titleError')); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="title"><?php echo e(__('main.Url')); ?></label>
                                                <input type="text"
                                                    class="form-control form-control-sm <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="link" name="link" value="<?php echo e(old('link')); ?>">
                                                <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="ml-auto text-danger"><?php echo e(__('main.linkError')); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>  
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="save-card">
                                <div class="card-body">
                                    <a href="javascript:void(0);" class="btn btn-success btn-sm float-right"
                                        id="submitmainmenu"><?php echo e(__('main.Save')); ?></a>
                                        <a href="<?php echo e(route('admin.mainmenu.index')); ?>" class="btn btn-danger btn-sm float-right mr-2">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                <div class="card">
                    <div class="card-header">
                        
                        <a href="<?php echo e(route('admin.mainmenu.trashed')); ?>" class="btn btn-warning btn-sm float-right"><i
                                class="fas fa-trash-alt"></i><?php echo e(__('main.Recycle')); ?></a>
                    </div>
                    <div class="card-body">
                        
                        <table id="table1" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('main.Title')); ?></th>
                                    <th><?php echo e(__('main.Url')); ?></th>
                                    <th><?php echo e(__('main.Creation Date')); ?></th>
                                    <th><?php echo e(__('main.Statu')); ?></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="maincontent">
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="row1" data-id="<?php echo e($article->id); ?>" data-row-id=<?php echo e($article->Position); ?> >
                                        <td><?php echo e($article->title); ?></td>
                                        <td><?php echo e($article->link); ?></td>
                                        <td><?php echo e($article->created_at->diffForHumans()); ?></td>
                                        <td><input class="switch" type="checkbox" name="my-checkbox"
                                                data-id="<?php echo e($article->id); ?>" <?php if($article->status == 1): ?> checked <?php endif; ?>
                                                data-toggle="toggle" data-size="mini"
                                                data-on="<?php echo e(__('main.Published')); ?>" data-off="<?php echo e(__('main.Draft')); ?>"
                                                data-onstyle="success" data-offstyle="danger"></td>
                                        <td> 
                                            <button
                                              id="editmainmenu"  data-id="<?php echo e($article->id); ?>" title="<?php echo e(__('main.Edit')); ?>" class="btn btn-primary btn-xs editmainmenu"><i
                                                    class="fas fa-pencil-alt"></i></button>
                                            <a href="<?php echo e(route('admin.mainmenu.delete', $article->id)); ?>"
                                                onclick="validate(<?php echo e($article->id); ?>)" title="<?php echo e(__('main.Delete')); ?>"
                                                class="btn btn-danger btn-xs"><i class="far fa-times-circle"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </div><!-- /.content -->
    </div>
   
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>


    <script>
        $('.switch').change(function() {
        id = $(this).attr('data-id');
        status = $(this).prop('checked');
        $.get("<?php echo e(secure_url(route('admin.mainmenu.statusupdate'))); ?>", {
            id: id,
            status: status
        });
    });

    $('.editmainmenu').click(function() {
    var id = $(this).data('id'); 
    $.get("<?php echo e(secure_url(route('admin.mainmenu.editmain'))); ?>", {
        id: id,
    })
    .done(function(response) {
        console.log(); 
        var link = response.data.link;
        var title = response.data.title;
        $('#link').val(link);    $('#label').text('Edit Mainmenu'); 
        $('#title').val(title); $('#submitmainmenu').text('Update'); 
        $('#typedata').val('update'); $('#id').val(response.data.id)
    })
    .fail(function(error) {
        console.error(error); 
        
    });
});
$( "tbody#maincontent" ).sortable({
        items: "tr",
        cursor: 'move',
        opacity: 0.6,
        update: function() {
            updatePostOrder('row1');
        }
    });
function updatePostOrder(row){
    var Position = [];
     var token = $('meta[name="csrf-token"]').attr('content');
            $('tr.'+row).each(function(index, element) {
            Position.push({
                id: $(this).attr('data-id'),
                Position: index+1
            });
        });
        $.post("<?php echo e(secure_url(route('admin.mainmenu.updateorder'))); ?>", {
         Position: Position,
         _token: token
    })
    .done(function(response) {
        console.log(response);  
    })
    .fail(function(error) {
        console.error(error); 
        
    });
        
}

$(document).ready(function() {
        // Sort the rows based on the data-row-id attribute in ascending order
        var rows = $('#maincontent tr').get();
        rows.sort(function(a, b) {
            var keyA = parseInt($(a).data('row-id'));
            var keyB = parseInt($(b).data('row-id'));
            return keyA - keyB;
        });
        $.each(rows, function(index, row) {
            $('#maincontent').append(row);
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MMI\mmi-backend\resources\views/admin/homemenu/mainmenu/index.blade.php ENDPATH**/ ?>